package com.glassextend.app.ui

import android.graphics.Bitmap
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.glassextend.app.Spec
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Draws [bitmap] inside a frame that grows with [spec], so you can see exactly where
 * new pixels will appear. With an empty spec and showFrame = false it is just a
 * rounded, rimmed photo view (used for the finished result).
 */
@Composable
fun ExtendPreview(
    bitmap: Bitmap,
    spec: Spec,
    modifier: Modifier = Modifier,
    showFrame: Boolean = true
) {
    val image = remember(bitmap) { bitmap.asImageBitmap() }
    val move = spring<Float>(stiffness = Spring.StiffnessMediumLow)
    val left = animateFloatAsState(spec.left, move, label = "left")
    val right = animateFloatAsState(spec.right, move, label = "right")
    val top = animateFloatAsState(spec.top, move, label = "top")
    val bottom = animateFloatAsState(spec.bottom, move, label = "bottom")

    Canvas(modifier) {
        val l = max(0f, left.value)
        val r = max(0f, right.value)
        val t = max(0f, top.value)
        val b = max(0f, bottom.value)

        val sw = image.width.toFloat()
        val sh = image.height.toFloat()
        val totalW = sw * (1f + l + r)
        val totalH = sh * (1f + t + b)
        val scale = min(size.width / totalW, size.height / totalH)

        val frameW = totalW * scale
        val frameH = totalH * scale
        val fx = (size.width - frameW) / 2f
        val fy = (size.height - frameH) / 2f

        if (showFrame) {
            val frameCorner = CornerRadius(20.dp.toPx())
            drawRoundRect(
                brush = Brush.linearGradient(
                    listOf(Color(0x558E7CFF), Color(0x5522D3EE)),
                    start = Offset(fx, fy),
                    end = Offset(fx + frameW, fy + frameH)
                ),
                topLeft = Offset(fx, fy),
                size = Size(frameW, frameH),
                cornerRadius = frameCorner
            )
            drawRoundRect(
                color = Color.White.copy(alpha = 0.75f),
                topLeft = Offset(fx, fy),
                size = Size(frameW, frameH),
                cornerRadius = frameCorner,
                style = Stroke(
                    width = 1.5.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(16.dp.toPx(), 10.dp.toPx()))
                )
            )
        }

        val ix = fx + l * sw * scale
        val iy = fy + t * sh * scale
        val iw = sw * scale
        val ih = sh * scale
        val photoCorner = CornerRadius(14.dp.toPx())

        val clip = Path().apply {
            addRoundRect(RoundRect(ix, iy, ix + iw, iy + ih, photoCorner))
        }
        clipPath(clip) {
            drawImage(
                image = image,
                srcSize = IntSize(image.width, image.height),
                dstOffset = IntOffset(ix.roundToInt(), iy.roundToInt()),
                dstSize = IntSize(iw.roundToInt(), ih.roundToInt()),
                filterQuality = FilterQuality.Medium
            )
        }
        drawRoundRect(
            color = Color.White.copy(alpha = 0.45f),
            topLeft = Offset(ix, iy),
            size = Size(iw, ih),
            cornerRadius = photoCorner,
            style = Stroke(width = 1.dp.toPx())
        )
    }
}
