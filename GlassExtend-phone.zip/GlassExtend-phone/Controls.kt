package com.glassextend.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.glassextend.app.ExtendViewModel
import com.glassextend.app.Provider
import com.glassextend.app.Side
import com.glassextend.app.Spec
import com.glassextend.app.UiState
import kotlin.math.roundToInt

private val Ratios = listOf(
    "1:1" to 1f,
    "4:5" to 0.8f,
    "3:4" to 0.75f,
    "2:3" to 2f / 3f,
    "9:16" to 9f / 16f,
    "3:2" to 1.5f,
    "4:3" to 4f / 3f,
    "16:9" to 16f / 9f
)

@Composable
private fun glassFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Color.White,
    unfocusedTextColor = Color.White,
    focusedBorderColor = Color.White.copy(alpha = 0.85f),
    unfocusedBorderColor = Color.White.copy(alpha = 0.30f),
    cursorColor = Color.White,
    focusedLabelColor = Color.White.copy(alpha = 0.85f),
    unfocusedLabelColor = Color.White.copy(alpha = 0.60f),
    focusedPlaceholderColor = Color.White.copy(alpha = 0.50f),
    unfocusedPlaceholderColor = Color.White.copy(alpha = 0.50f)
)

/** The bottom panel while editing: shape chips, optional fine-tune sliders, mode, prompt, go button. */
@Composable
fun Controls(state: UiState, vm: ExtendViewModel, modifier: Modifier = Modifier) {
    val caption = when {
        state.spec.isEmpty -> "Pick a shape, or use Custom to choose how far to extend each side."
        state.useAi -> "AI paints the new area. Needs internet and an API key (Settings)."
        else -> "Instant blurred fill. Works offline."
    }

    GlassPanel(modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier
                .heightIn(max = 360.dp)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    GlassChip("Custom", selected = state.custom, onClick = { vm.toggleCustom() })
                }
                items(Ratios) { (label, value) ->
                    GlassChip(
                        text = label,
                        selected = state.ratio == label,
                        onClick = { vm.applyRatio(label, value) }
                    )
                }
            }

            AnimatedVisibility(visible = state.custom) {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    SideSlider("Left", state.spec.left) { vm.setSide(Side.Left, it) }
                    SideSlider("Right", state.spec.right) { vm.setSide(Side.Right, it) }
                    SideSlider("Top", state.spec.top) { vm.setSide(Side.Top, it) }
                    SideSlider("Bottom", state.spec.bottom) { vm.setSide(Side.Bottom, it) }
                    GlassChip("Reset", selected = false, onClick = { vm.resetSpec() })
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassChip("AI Extend", state.useAi, { vm.setUseAi(true) }, Modifier.weight(1f))
                GlassChip("Quick fill", !state.useAi, { vm.setUseAi(false) }, Modifier.weight(1f))
            }

            Text(caption, fontSize = 12.sp, color = Color.White.copy(alpha = 0.7f))

            // Only Stability's outpaint takes a text prompt; Clipdrop's uncrop has none.
            if (state.useAi && state.provider == Provider.STABILITY) {
                OutlinedTextField(
                    value = state.prompt,
                    onValueChange = { vm.setPrompt(it) },
                    placeholder = { Text("Describe the scene (optional)") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = glassFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            GlassButton(
                text = if (state.busy) "Working…" else "Extend photo",
                modifier = Modifier.fillMaxWidth(),
                primary = true,
                enabled = !state.busy && !state.spec.isEmpty,
                icon = Icons.Default.Star,
                onClick = { vm.generate() }
            )
        }
    }
}

@Composable
private fun SideSlider(label: String, value: Float, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 13.sp, modifier = Modifier.width(54.dp))
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = 0f..Spec.MAX_SIDE,
            modifier = Modifier.weight(1f),
            colors = SliderDefaults.colors(
                thumbColor = Color.White,
                activeTrackColor = Color.White.copy(alpha = 0.9f),
                inactiveTrackColor = Color.White.copy(alpha = 0.22f)
            )
        )
        Text(
            "${(value * 100).roundToInt()}%",
            fontSize = 13.sp,
            textAlign = TextAlign.End,
            modifier = Modifier.width(48.dp)
        )
    }
}

/** The bottom panel once a result exists. */
@Composable
fun ResultActions(
    saved: Boolean,
    onSave: () -> Unit,
    onShare: () -> Unit,
    onExtendMore: () -> Unit,
    onAdjust: () -> Unit,
    modifier: Modifier = Modifier
) {
    GlassPanel(modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GlassButton(
                    text = if (saved) "Saved" else "Save",
                    modifier = Modifier.weight(1f),
                    primary = !saved,
                    enabled = !saved,
                    icon = if (saved) Icons.Default.Check else null,
                    onClick = onSave
                )
                GlassButton(
                    text = "Share",
                    modifier = Modifier.weight(1f),
                    primary = true,
                    icon = Icons.Default.Share,
                    onClick = onShare
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GlassButton(text = "Extend more", modifier = Modifier.weight(1f), onClick = onExtendMore)
                GlassButton(text = "Adjust", modifier = Modifier.weight(1f), onClick = onAdjust)
            }
        }
    }
}

@Composable
fun SettingsDialog(state: UiState, vm: ExtendViewModel) {
    val uriHandler = LocalUriHandler.current
    Dialog(onDismissRequest = { vm.closeSettings() }) {
        GlassPanel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("AI provider", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Provider.entries.forEach { p ->
                        GlassChip(p.label, selected = p == state.provider, onClick = { vm.setProvider(p) })
                    }
                }
                Text(state.provider.note, fontSize = 13.sp, color = Color.White.copy(alpha = 0.75f))
                OutlinedTextField(
                    value = state.keys[state.provider].orEmpty(),
                    onValueChange = { vm.setKey(it) },
                    label = { Text("API key") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    shape = RoundedCornerShape(16.dp),
                    colors = glassFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    GlassButton(
                        text = "Get a key",
                        modifier = Modifier.weight(1f),
                        onClick = { uriHandler.openUri(state.provider.keyUrl) }
                    )
                    GlassButton(
                        text = "Done",
                        modifier = Modifier.weight(1f),
                        primary = true,
                        onClick = { vm.closeSettings() }
                    )
                }
                Text(
                    "Your key is stored only on this phone and sent only to the provider you pick.",
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.6f)
                )
            }
        }
    }
}
