package com.glassextend.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.glassextend.app.ExtendViewModel
import com.glassextend.app.Spec
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun AppScreen(initialUri: Uri?, vm: ExtendViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.load(uri)
    }
    val pickPhoto = {
        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    // A photo shared into the app from the gallery: load it once, not again after rotation.
    var handled by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(initialUri) {
        if (!handled && initialUri != null) {
            handled = true
            vm.load(initialUri)
        }
    }

    // Auto-dismiss the toast.
    LaunchedEffect(state.message) {
        if (state.message != null) {
            delay(3500)
            vm.clearMessage()
        }
    }

    BackHandler(enabled = state.result != null) { vm.discardResult() }
    BackHandler(enabled = state.source != null && state.result == null) { vm.newPhoto() }

    Box(Modifier.fillMaxSize()) {
        AuroraBackground()

        Column(
            Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .imePadding()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            TopBar(
                hasPhoto = state.source != null,
                onNew = { vm.newPhoto() },
                onSettings = { vm.openSettings() }
            )
            Spacer(Modifier.height(14.dp))

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                val source = state.source
                val result = state.result
                when {
                    source == null -> EmptyCard(onPick = pickPhoto)
                    result != null -> ExtendPreview(result, Spec(), Modifier.fillMaxSize(), showFrame = false)
                    else -> ExtendPreview(source, state.spec, Modifier.fillMaxSize())
                }
                if (state.busy) BusyCard(ai = state.useAi)
            }

            if (state.source != null) {
                Spacer(Modifier.height(14.dp))
                if (state.result != null) {
                    ResultActions(
                        saved = state.savedUri != null,
                        onSave = { scope.launch { vm.ensureSaved() } },
                        onShare = {
                            scope.launch {
                                val uri = vm.ensureSaved()
                                if (uri != null) share(context, uri)
                            }
                        },
                        onExtendMore = { vm.useResultAsSource() },
                        onAdjust = { vm.discardResult() }
                    )
                } else {
                    Controls(state, vm)
                }
            }
        }

        AnimatedVisibility(
            visible = state.message != null,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .systemBarsPadding()
                .padding(top = 72.dp, start = 24.dp, end = 24.dp),
            enter = fadeIn() + slideInVertically(),
            exit = fadeOut()
        ) {
            GlassPanel(corner = 20.dp) {
                Text(
                    text = state.message.orEmpty(),
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp),
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )
            }
        }

        if (state.showSettings) SettingsDialog(state, vm)
    }
}

private fun share(context: Context, uri: Uri) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "image/jpeg"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(send, null))
}

@Composable
private fun TopBar(hasPhoto: Boolean, onNew: () -> Unit, onSettings: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        GlassPanel(corner = 50.dp) {
            Text(
                text = "Glass Extend",
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 11.dp),
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(Modifier.weight(1f))
        if (hasPhoto) {
            GlassIconButton(Icons.Default.Add, "New photo", onNew)
            Spacer(Modifier.width(10.dp))
        }
        GlassIconButton(Icons.Default.Settings, "Settings", onSettings)
    }
}

@Composable
private fun EmptyCard(onPick: () -> Unit) {
    GlassPanel(Modifier.fillMaxWidth(), corner = 36.dp) {
        Column(
            modifier = Modifier.padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "Uncrop any photo",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Text(
                text = "Pick a photo, choose a new shape, and let AI paint beyond the edges.",
                fontSize = 15.sp,
                textAlign = TextAlign.Center,
                color = Color.White.copy(alpha = 0.75f)
            )
            Spacer(Modifier.height(4.dp))
            GlassButton(
                text = "Choose photo",
                primary = true,
                icon = Icons.Default.Add,
                onClick = onPick
            )
        }
    }
}

@Composable
private fun BusyCard(ai: Boolean) {
    GlassPanel(corner = 24.dp) {
        Row(
            modifier = Modifier.padding(horizontal = 22.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.5.dp)
            Spacer(Modifier.width(14.dp))
            Text(if (ai) "Painting beyond the edges…" else "Filling the edges…", fontSize = 15.sp)
        }
    }
}
