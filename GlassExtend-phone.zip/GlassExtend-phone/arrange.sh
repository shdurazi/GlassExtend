#!/bin/bash
# Rebuilds the Android project folders from the flat files uploaded to the repo root.
set -e
if [ -f app-build.gradle.kts ]; then
  J=app/src/main/java/com/glassextend/app
  mkdir -p $J/ui app/src/main/res/values app/src/main/res/drawable app/src/main/res/mipmap-anydpi-v26
  mv app-build.gradle.kts app/build.gradle.kts
  mv proguard-rules.pro app/
  mv AndroidManifest.xml app/src/main/
  mv Imaging.kt Outpaint.kt ExtendViewModel.kt MainActivity.kt $J/
  mv GlassTheme.kt Preview.kt Controls.kt Screens.kt $J/ui/
  mv strings.xml colors.xml themes.xml app/src/main/res/values/
  mv ic_launcher_background.xml ic_launcher_foreground.xml app/src/main/res/drawable/
  mv ic_launcher.xml app/src/main/res/mipmap-anydpi-v26/
fi
