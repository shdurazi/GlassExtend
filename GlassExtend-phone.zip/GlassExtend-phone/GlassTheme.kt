package com.glassextend.app.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val GlassColors = darkColorScheme(
    primary = Color(0xFFB8A6FF),
    onPrimary = Color(0xFF14102B),
    secondary = Color(0xFF7DE8FF),
    background = Color(0xFF0A0F24),
    surface = Color(0xFF111A3A),
    onBackground = Color.White,
    onSurface = Color.White
)

@Composable
fun GlassTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = GlassColors) {
        CompositionLocalProvider(LocalContentColor provides Color.White) {
            content()
        }
    }
}

/** Specular rim light: bright top-left, dim middle, soft bounce bottom-right. */
private fun rim(strength: Float = 0.70f): Brush = Brush.linearGradient(
    listOf(
        Color.White.copy(alpha = strength),
        Color.White.copy(alpha = 0.08f),
        Color.White.copy(alpha = 0.30f)
    )
)

// ---------------------------------------------------------------- background

@Composable
fun AuroraBackground(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "aurora")
    val a = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(16000, easing = LinearEasing), RepeatMode.Reverse),
        label = "a"
    )
    val b = transition.animateFloat(
        initialValue = 1f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(23000, easing = LinearEasing), RepeatMode.Reverse),
        label = "b"
    )
    // State is read inside the draw block, so the animation only redraws; nothing recomposes.
    Canvas(modifier.fillMaxSize()) {
        drawRect(
            Brush.verticalGradient(listOf(Color(0xFF0A0F24), Color(0xFF111A3C), Color(0xFF0A0F24)))
        )
        val w = size.width
        val h = size.height
        val t = a.value
        val u = b.value
        blob(Color(0xFF7C5CFF), Offset(w * (0.10f + 0.55f * t), h * (0.18f + 0.12f * u)), w * 0.85f, 0.75f)
        blob(Color(0xFF16C6E8), Offset(w * (0.95f - 0.60f * t), h * (0.55f + 0.15f * u)), w * 0.80f, 0.55f)
        blob(Color(0xFFFF5CAA), Offset(w * (0.25f + 0.40f * u), h * (0.92f - 0.18f * t)), w * 0.75f, 0.50f)
    }
}

private fun DrawScope.blob(color: Color, center: Offset, radius: Float, alpha: Float) {
    drawCircle(
        brush = Brush.radialGradient(
            listOf(color.copy(alpha = alpha), Color.Transparent),
            center = center,
            radius = radius
        ),
        radius = radius,
        center = center
    )
}

// ---------------------------------------------------------------- interaction

/** Click with a springy "squish" while pressed, so glass feels like it has give. */
fun Modifier.squishClick(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed && enabled) 0.94f else 1f,
        animationSpec = spring(dampingRatio = 0.4f, stiffness = Spring.StiffnessMedium),
        label = "squish"
    )
    this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clickable(
            interactionSource = source,
            indication = null,
            enabled = enabled,
            onClick = onClick
        )
}

// ---------------------------------------------------------------- glass pieces

@Composable
fun GlassPanel(
    modifier: Modifier = Modifier,
    corner: Dp = 28.dp,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(corner)
    Box(
        modifier = modifier
            .shadow(
                elevation = 20.dp,
                shape = shape,
                clip = false,
                ambientColor = Color(0x40000000),
                spotColor = Color(0x50000000)
            )
            .clip(shape)
            .background(
                Brush.linearGradient(
                    listOf(Color.White.copy(alpha = 0.24f), Color.White.copy(alpha = 0.07f))
                )
            )
            .border(1.dp, rim(), shape),
        content = content
    )
}

@Composable
fun GlassButton(
    text: String,
    modifier: Modifier = Modifier,
    primary: Boolean = false,
    enabled: Boolean = true,
    icon: ImageVector? = null,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(50)
    val fill = if (primary) {
        Brush.linearGradient(
            listOf(Color(0xFF8E7CFF).copy(alpha = 0.90f), Color(0xFF22D3EE).copy(alpha = 0.80f))
        )
    } else {
        Brush.linearGradient(
            listOf(Color.White.copy(alpha = 0.22f), Color.White.copy(alpha = 0.07f))
        )
    }
    Row(
        modifier = modifier
            .alpha(if (enabled) 1f else 0.45f)
            .squishClick(enabled = enabled, onClick = onClick)
            .clip(shape)
            .background(fill)
            .border(1.dp, rim(), shape)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
fun GlassIconButton(icon: ImageVector, description: String, onClick: () -> Unit) {
    GlassPanel(
        modifier = Modifier
            .size(46.dp)
            .squishClick(onClick = onClick),
        corner = 23.dp
    ) {
        Icon(
            icon,
            contentDescription = description,
            modifier = Modifier
                .align(Alignment.Center)
                .size(22.dp)
        )
    }
}

@Composable
fun GlassChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(50)
    val fill = if (selected) {
        Brush.linearGradient(listOf(Color.White.copy(alpha = 0.42f), Color.White.copy(alpha = 0.18f)))
    } else {
        Brush.linearGradient(listOf(Color.White.copy(alpha = 0.16f), Color.White.copy(alpha = 0.05f)))
    }
    Box(
        modifier = modifier
            .squishClick(onClick = onClick)
            .clip(shape)
            .background(fill)
            .border(1.dp, Color.White.copy(alpha = if (selected) 0.85f else 0.28f), shape)
            .padding(horizontal = 16.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            fontSize = 14.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1
        )
    }
}
