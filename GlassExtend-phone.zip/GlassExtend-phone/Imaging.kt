package com.glassextend.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorSpace
import android.graphics.ImageDecoder
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.Shader
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

enum class Side { Left, Right, Top, Bottom }

/** How far to grow each side, as a fraction of the original width (left/right) or height (top/bottom). */
data class Spec(
    val left: Float = 0f,
    val right: Float = 0f,
    val top: Float = 0f,
    val bottom: Float = 0f
) {
    val isEmpty: Boolean
        get() = left < 0.005f && right < 0.005f && top < 0.005f && bottom < 0.005f

    companion object {
        const val MAX_SIDE = 1.5f

        /** Centered extension so the photo reaches [ratio] (= width / height). */
        fun forRatio(width: Int, height: Int, ratio: Float): Spec {
            val current = width.toFloat() / height
            return when {
                ratio > current * 1.005f -> {
                    val each = ((height * ratio / width - 1f) / 2f).coerceIn(0f, MAX_SIDE)
                    Spec(left = each, right = each)
                }
                ratio < current / 1.005f -> {
                    val each = ((width / (ratio * height) - 1f) / 2f).coerceIn(0f, MAX_SIDE)
                    Spec(top = each, bottom = each)
                }
                else -> Spec()
            }
        }
    }
}

/** Pixel geometry for one job: the (possibly downscaled) photo plus the pixels added on each side. */
data class Plan(
    val srcW: Int,
    val srcH: Int,
    val left: Int,
    val right: Int,
    val top: Int,
    val bottom: Int
) {
    val outW: Int get() = srcW + left + right
    val outH: Int get() = srcH + top + bottom

    companion object {
        fun of(
            w: Int,
            h: Int,
            spec: Spec,
            maxEdge: Int,
            maxPixels: Int,
            maxSide: Int = Int.MAX_VALUE
        ): Plan {
            val cw = w * (1f + spec.left + spec.right)
            val ch = h * (1f + spec.top + spec.bottom)
            var k = 1f
            k = min(k, maxEdge / max(cw, ch))
            k = min(k, sqrt(maxPixels / (cw * ch)))
            val widest = max(max(spec.left, spec.right) * w, max(spec.top, spec.bottom) * h)
            if (widest > 0f) k = min(k, maxSide / widest)
            return Plan(
                srcW = max(1, (w * k).roundToInt()),
                srcH = max(1, (h * k).roundToInt()),
                left = max(0, (spec.left * w * k).roundToInt()),
                right = max(0, (spec.right * w * k).roundToInt()),
                top = max(0, (spec.top * h * k).roundToInt()),
                bottom = max(0, (spec.bottom * h * k).roundToInt())
            )
        }
    }
}

object Compositor {

    fun scaleTo(src: Bitmap, w: Int, h: Int): Bitmap =
        if (src.width == w && src.height == h) src else Bitmap.createScaledBitmap(src, w, h, true)

    fun toJpeg(bitmap: Bitmap, quality: Int): ByteArray {
        val out = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)
        return out.toByteArray()
    }

    /** Offline fill: a soft blurred copy of the photo behind the original. Instant. */
    fun quickFill(src: Bitmap, plan: Plan): Bitmap {
        val photo = scaleTo(src, plan.srcW, plan.srcH)
        return compose(plan, photo, feather = 0.05f) { canvas, paint ->
            drawBlurredCover(canvas, paint, photo, plan.outW, plan.outH)
        }
    }

    /** Puts the AI-generated picture behind the untouched original, with a soft seam. */
    fun aiFill(src: Bitmap, generated: Bitmap, plan: Plan): Bitmap {
        val photo = scaleTo(src, plan.srcW, plan.srcH)
        return compose(plan, photo, feather = 0.02f) { canvas, paint ->
            canvas.drawBitmap(generated, null, Rect(0, 0, plan.outW, plan.outH), paint)
        }
    }

    private fun compose(
        plan: Plan,
        photo: Bitmap,
        feather: Float,
        background: (Canvas, Paint) -> Unit
    ): Bitmap {
        val out = Bitmap.createBitmap(plan.outW, plan.outH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG or Paint.DITHER_FLAG)
        background(canvas, paint)

        val f = (min(plan.srcW, plan.srcH) * feather).roundToInt().coerceIn(3, 48).toFloat()
        val l = plan.left.toFloat()
        val t = plan.top.toFloat()
        val r = l + plan.srcW
        val b = t + plan.srcH
        val clear = Color.TRANSPARENT
        val solid = Color.BLACK

        // Draw the original, then fade its alpha out along every edge that touches new space.
        val layer = canvas.saveLayer(0f, 0f, plan.outW.toFloat(), plan.outH.toFloat(), null)
        canvas.drawBitmap(photo, l, t, paint)
        val mask = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
        if (plan.left > 0) {
            mask.shader = LinearGradient(l, 0f, l + f, 0f, clear, solid, Shader.TileMode.CLAMP)
            canvas.drawRect(l, t, l + f, b, mask)
        }
        if (plan.right > 0) {
            mask.shader = LinearGradient(r - f, 0f, r, 0f, solid, clear, Shader.TileMode.CLAMP)
            canvas.drawRect(r - f, t, r, b, mask)
        }
        if (plan.top > 0) {
            mask.shader = LinearGradient(0f, t, 0f, t + f, clear, solid, Shader.TileMode.CLAMP)
            canvas.drawRect(l, t, r, t + f, mask)
        }
        if (plan.bottom > 0) {
            mask.shader = LinearGradient(0f, b - f, 0f, b, solid, clear, Shader.TileMode.CLAMP)
            canvas.drawRect(l, b - f, r, b, mask)
        }
        canvas.restoreToCount(layer)
        return out
    }

    /** Center-crops [src] to the output shape, shrinks it to a few pixels, and stretches it back up. */
    private fun drawBlurredCover(canvas: Canvas, paint: Paint, src: Bitmap, outW: Int, outH: Int) {
        val targetAspect = outW.toFloat() / outH
        val srcAspect = src.width.toFloat() / src.height
        val crop = if (srcAspect > targetAspect) {
            val cw = (src.height * targetAspect).roundToInt().coerceIn(1, src.width)
            val x = (src.width - cw) / 2
            Rect(x, 0, x + cw, src.height)
        } else {
            val ch = (src.width / targetAspect).roundToInt().coerceIn(1, src.height)
            val y = (src.height - ch) / 2
            Rect(0, y, src.width, y + ch)
        }
        var tiny = Bitmap.createBitmap(src, crop.left, crop.top, crop.width(), crop.height())
        while (max(tiny.width, tiny.height) > 40) {
            tiny = Bitmap.createScaledBitmap(
                tiny,
                max(1, tiny.width / 2),
                max(1, tiny.height / 2),
                true
            )
        }
        canvas.drawBitmap(tiny, null, Rect(0, 0, outW, outH), paint)
    }
}

object PhotoIO {

    /** Decodes a photo (EXIF rotation applied) down to at most [maxEdge] px on its long side. */
    fun decode(context: Context, uri: Uri, maxEdge: Int = 2048): Bitmap {
        val source = ImageDecoder.createSource(context.contentResolver, uri)
        return ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
            decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE)
            decoder.setTargetColorSpace(ColorSpace.get(ColorSpace.Named.SRGB))
            val edge = max(info.size.width, info.size.height)
            var sample = 1
            while (edge / sample > maxEdge) sample *= 2
            if (sample > 1) decoder.setTargetSampleSize(sample)
        }
    }

    /** Saves to Pictures/GlassExtend and returns the gallery Uri, or null on failure. */
    fun saveJpeg(context: Context, bitmap: Bitmap): Uri? {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "GlassExtend_$stamp.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/GlassExtend")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        return try {
            val ok = resolver.openOutputStream(uri)?.use {
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, it)
            } ?: false
            if (!ok) throw IllegalStateException("compress failed")
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            uri
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            null
        }
    }
}
