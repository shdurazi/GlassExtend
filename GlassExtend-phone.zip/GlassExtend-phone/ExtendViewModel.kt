package com.glassextend.app

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class UiState(
    val source: Bitmap? = null,
    val spec: Spec = Spec(),
    val ratio: String? = null,
    val custom: Boolean = false,
    val useAi: Boolean = true,
    val prompt: String = "",
    val busy: Boolean = false,
    val result: Bitmap? = null,
    val savedUri: Uri? = null,
    val message: String? = null,
    val showSettings: Boolean = false,
    val provider: Provider = Provider.CLIPDROP,
    val keys: Map<Provider, String> = emptyMap()
)

class ExtendViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("glass_extend", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(
        UiState(
            useAi = prefs.getBoolean("use_ai", true),
            provider = Provider.fromId(prefs.getString("provider", null)),
            keys = Provider.entries.associateWith { prefs.getString("key_${it.id}", "").orEmpty() }
        )
    )
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var job: Job? = null

    // ---- photo ----

    fun load(uri: Uri) {
        job?.cancel()
        viewModelScope.launch {
            val bitmap = withContext(Dispatchers.IO) {
                runCatching { PhotoIO.decode(getApplication<Application>(), uri) }.getOrNull()
            }
            if (bitmap == null) {
                toast("Couldn't open that photo.")
            } else {
                _state.update {
                    it.copy(
                        source = bitmap,
                        spec = Spec(),
                        ratio = null,
                        custom = false,
                        result = null,
                        savedUri = null,
                        busy = false
                    )
                }
            }
        }
    }

    fun newPhoto() {
        job?.cancel()
        _state.update {
            it.copy(source = null, result = null, savedUri = null, spec = Spec(), ratio = null, busy = false)
        }
    }

    // ---- extension controls ----

    fun applyRatio(label: String, ratio: Float) {
        val src = _state.value.source ?: return
        _state.update { it.copy(spec = Spec.forRatio(src.width, src.height, ratio), ratio = label) }
    }

    fun setSide(side: Side, value: Float) {
        _state.update { s ->
            val sp = s.spec
            val next = when (side) {
                Side.Left -> sp.copy(left = value)
                Side.Right -> sp.copy(right = value)
                Side.Top -> sp.copy(top = value)
                Side.Bottom -> sp.copy(bottom = value)
            }
            s.copy(spec = next, ratio = null)
        }
    }

    fun resetSpec() = _state.update { it.copy(spec = Spec(), ratio = null) }

    fun toggleCustom() = _state.update { it.copy(custom = !it.custom) }

    fun setPrompt(value: String) = _state.update { it.copy(prompt = value) }

    fun setUseAi(value: Boolean) {
        prefs.edit().putBoolean("use_ai", value).apply()
        _state.update { it.copy(useAi = value) }
    }

    // ---- settings ----

    fun openSettings() = _state.update { it.copy(showSettings = true) }

    fun closeSettings() = _state.update { it.copy(showSettings = false) }

    fun setProvider(provider: Provider) {
        prefs.edit().putString("provider", provider.id).apply()
        _state.update { it.copy(provider = provider) }
    }

    fun setKey(value: String) {
        val provider = _state.value.provider
        prefs.edit().putString("key_${provider.id}", value).apply()
        _state.update { it.copy(keys = it.keys + (provider to value)) }
    }

    // ---- messages ----

    fun toast(text: String) = _state.update { it.copy(message = text) }

    fun clearMessage() = _state.update { it.copy(message = null) }

    // ---- generate ----

    fun generate() {
        val s = _state.value
        val source = s.source ?: return
        if (s.busy || s.spec.isEmpty) return
        val key = s.keys[s.provider].orEmpty().trim()
        if (s.useAi && key.isEmpty()) {
            _state.update {
                it.copy(showSettings = true, message = "Add an API key to use AI Extend, or switch to Quick fill.")
            }
            return
        }
        _state.update { it.copy(busy = true, message = null) }
        job = viewModelScope.launch {
            val outcome = withContext(Dispatchers.Default) {
                runCatching { if (s.useAi) runAi(source, s, key) else runQuick(source, s) }
            }
            outcome
                .onSuccess { bitmap ->
                    _state.update { it.copy(busy = false, result = bitmap, savedUri = null) }
                }
                .onFailure { e ->
                    val text = if (e is OutOfMemoryError) {
                        "Not enough memory. Try a smaller extension."
                    } else {
                        e.message ?: "Something went wrong."
                    }
                    _state.update { it.copy(busy = false, message = text) }
                }
        }
    }

    private suspend fun runAi(source: Bitmap, s: UiState, key: String): Bitmap {
        val plan = Plan.of(
            source.width, source.height, s.spec,
            maxEdge = 2560, maxPixels = 4_000_000, maxSide = 2000
        )
        val photo = Compositor.scaleTo(source, plan.srcW, plan.srcH)
        val jpeg = Compositor.toJpeg(photo, 92)
        val bytes = withContext(Dispatchers.IO) {
            OutpaintClient.extend(s.provider, key, jpeg, plan, s.prompt)
        }
        val generated = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            ?: throw ApiException("The service didn't return a usable image.")
        return Compositor.aiFill(photo, generated, plan)
    }

    private fun runQuick(source: Bitmap, s: UiState): Bitmap {
        val plan = Plan.of(source.width, source.height, s.spec, maxEdge = 3072, maxPixels = 8_000_000)
        return Compositor.quickFill(source, plan)
    }

    // ---- result ----

    fun discardResult() = _state.update { it.copy(result = null, savedUri = null) }

    fun useResultAsSource() {
        job?.cancel()
        _state.update { s ->
            val r = s.result
            if (r == null) s else s.copy(
                source = r,
                result = null,
                savedUri = null,
                spec = Spec(),
                ratio = null,
                custom = false
            )
        }
    }

    /** Saves the result to the gallery once and returns its Uri (null if saving failed). */
    suspend fun ensureSaved(): Uri? {
        val s = _state.value
        s.savedUri?.let { return it }
        val bitmap = s.result ?: return null
        val uri = withContext(Dispatchers.IO) { PhotoIO.saveJpeg(getApplication<Application>(), bitmap) }
        if (uri == null) {
            toast("Couldn't save the image.")
        } else {
            _state.update { it.copy(savedUri = uri, message = "Saved to Pictures/GlassExtend") }
        }
        return uri
    }
}
