package com.glassextend.app

import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

enum class Provider(
    val id: String,
    val label: String,
    val keyUrl: String,
    val note: String
) {
    CLIPDROP(
        "clipdrop",
        "Clipdrop",
        "https://clipdrop.co/apis",
        "Clipdrop Uncrop: 1 credit per photo. Per Clipdrop's docs, new logins can claim 100 free test credits."
    ),
    STABILITY(
        "stability",
        "Stability AI",
        "https://platform.stability.ai/account/keys",
        "Stability outpaint: pay-as-you-go credits, about 4 per photo."
    );

    companion object {
        fun fromId(id: String?): Provider = Provider.entries.firstOrNull { it.id == id } ?: CLIPDROP
    }
}

class ApiException(message: String) : Exception(message)

object OutpaintClient {

    /** Sends [jpeg] to the provider and returns the extended image bytes. Blocking: call off the main thread. */
    fun extend(provider: Provider, apiKey: String, jpeg: ByteArray, plan: Plan, prompt: String): ByteArray {
        val boundary = "GlassExtend" + System.nanoTime()
        val form = Form(boundary)
        val url: String
        val headers = LinkedHashMap<String, String>()

        if (provider == Provider.CLIPDROP) {
            url = "https://clipdrop-api.co/uncrop/v1"
            headers["x-api-key"] = apiKey
            form.file("image_file", jpeg)
            form.field("extend_left", plan.left.toString())
            form.field("extend_right", plan.right.toString())
            form.field("extend_up", plan.top.toString())
            form.field("extend_down", plan.bottom.toString())
        } else {
            url = "https://api.stability.ai/v2beta/stable-image/edit/outpaint"
            headers["Authorization"] = "Bearer $apiKey"
            headers["Accept"] = "image/*"
            form.file("image", jpeg)
            form.field("left", plan.left.toString())
            form.field("right", plan.right.toString())
            form.field("up", plan.top.toString())
            form.field("down", plan.bottom.toString())
            form.field("output_format", "jpeg")
            if (prompt.isNotBlank()) form.field("prompt", prompt.trim())
        }
        val body = form.finish()

        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 20_000
            conn.readTimeout = 150_000
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            for ((name, value) in headers) conn.setRequestProperty(name, value)
            conn.setFixedLengthStreamingMode(body.size)
            conn.outputStream.use { it.write(body) }

            val code = conn.responseCode
            if (code in 200..299) {
                if (conn.getHeaderField("finish-reason") == "CONTENT_FILTERED") {
                    throw ApiException("The provider's safety filter blocked this photo.")
                }
                return conn.inputStream.use { it.readBytes() }
            }
            val raw = conn.errorStream?.use { it.readBytes().decodeToString() }.orEmpty()
            throw ApiException(describe(code, raw))
        } catch (e: IOException) {
            throw ApiException("Network problem: " + (e.message ?: "couldn't reach the service"))
        } finally {
            conn.disconnect()
        }
    }

    private fun describe(code: Int, body: String): String {
        val detail: String? = try {
            val json = JSONObject(body)
            when {
                json.has("error") -> json.optString("error")
                json.has("errors") -> json.optJSONArray("errors")?.let { arr ->
                    (0 until arr.length()).joinToString("; ") { arr.optString(it) }
                }
                json.has("message") -> json.optString("message")
                else -> null
            }
        } catch (e: Exception) {
            null
        }
        val hint: String? = when (code) {
            401, 403 -> "Check your API key in Settings."
            402 -> "Out of credits."
            429 -> "Too many requests. Try again in a moment."
            else -> null
        }
        return listOfNotNull(
            "Error $code",
            detail?.take(200)?.takeIf { it.isNotBlank() },
            hint
        ).joinToString(" · ")
    }

    private class Form(private val boundary: String) {
        private val out = ByteArrayOutputStream()

        fun field(name: String, value: String) {
            out.write(
                ("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$value\r\n").toByteArray()
            )
        }

        fun file(name: String, bytes: ByteArray) {
            out.write(
                ("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"; filename=\"photo.jpg\"\r\n" +
                    "Content-Type: image/jpeg\r\n\r\n").toByteArray()
            )
            out.write(bytes)
            out.write("\r\n".toByteArray())
        }

        fun finish(): ByteArray {
            out.write("--$boundary--\r\n".toByteArray())
            return out.toByteArray()
        }
    }
}
